# Expense Tracker

A tool for recording, analyzing, and managing everyday financial transactions.

### Features

- [x] List Transactions
- [x] Add Income/Expenses
- [x] Delete Income/Expenses
- [x] Total Balance

### Screenshots

![Expense Tracker](https://raw.githubusercontent.com/refinedguides/expense-tracker-js/main/screenshot.png)

### Support Me

If you'd like to support me, consider buying me a coffee. Thanks!

[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/refinedguides)
